# user_name = input('Enter your username: ')

password = input('Enter your password: ').split(',')
list_password = []
list_len = []
list_crc = ['$', '#', '@']
list_pass = ['a_z', '0_9', 'A_Z', '$_#_@']
for i in range(len(password)):

    dic_password = {'a_z': 0, '0_9': 0, 'A_Z': 0, '$_#_@': 0}
    for j in password[i]:
        if j.isalpha():
            if j.isupper():
                dic_password['A_Z'] += 1
            elif j.islower():
                dic_password['a_z'] += 1
        elif j.isdigit():
            dic_password['0_9'] += 1
        elif j in list_crc:
            dic_password['$_#_@'] += 1

    list_password.append(dic_password)

list_password_avalied = []
for l in range(len(password)):
    if len(password[l]) >= 6 and len(password[l]) <= 12:
        for h in range(len(list_password)):
            for k in list_pass:
                if list_password[h][k] < 1:
                    print(f'{password[h]} has error in {k} part !!!')

        break

    else:
        print(f'{password[l]}error in length part !!!')
for n in range(len(list_password)):
        if list_password[n][k] == 0:
            break
        else:
            list_password_avalied.append(password[n])

print(f'Password that they are correct is {list_password_avalied}')








