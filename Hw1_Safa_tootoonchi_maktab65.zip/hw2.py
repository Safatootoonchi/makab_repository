def time_disaply():
    second1, minutes1, hour1 = (input("Enter time1: ").split(":"))
    second2, minutes2, hour2 = (input("Enter time1: ").split(":"))

    if int(minutes2) <= 60 and int(minutes2) <= 60 and int(second1) <= 60 and int(second2) <= 60:
        second_total = (int(second2) + int(second1)) % 60
        minutes_total = (int(minutes2) + int(minutes1)) % 60 + (int(second2) + int(second1)) // 60
        hour_total = (int(hour2) + int(hour1)) + (int(minutes2) + int(minutes1)) // 60
        print(f'Time is {hour_total} hour(s) and {minutes_total} minute(s) and {second_total} second(s)')
    else:
        print('minute and second must be smaller than 60 in real. ')


time_disaply()