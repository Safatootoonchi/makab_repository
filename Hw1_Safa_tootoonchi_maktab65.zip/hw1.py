def Add():
    list_key = []
    dict1 = dict()
    for i in range(5):
        key = input(f'Enter your key{i + 1}: ')
        value = input(f'Enter your value{i + 1}: ')

        if key in list_key:
            print("It is a duplicate key")

        else:
            print("Successfuly added!")
            dict1.update({key: value})
        list_key.append(key)

    return dict1


dict1 = Add()


def Remove(dict1):
    key = input(f'Enter your key: ')
    value = input(f'Enter your value: ')
    if key in dict1.keys():
        if value == dict1[key]:
            del dict1[key]
        else:
            print('the value send incorrent.')

    return dict1


print(Remove(dict1))


